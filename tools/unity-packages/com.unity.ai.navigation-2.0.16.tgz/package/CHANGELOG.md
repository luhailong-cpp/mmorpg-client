# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [2.0.16] - 2026-10-07
### Changed
* A NavMesh baked over a terrain now includes the trees painted on that terrain. This is a consequence of the bug fix listed in the **Fixed** section below, where the trees were incorrectly left out of the bake, and not a new design decision. It can change the NavMesh substantially compared to previous versions of the package: agents have to path around trees that previously left no trace in the NavMesh, and a densely forested terrain can lose routes that used to exist. Baking such a terrain also takes longer and produces a larger NavMesh. NavMesh assets that are already baked keep working and only change when you bake them again. To keep a tree out of the NavMesh, add a **NavMesh Modifier** component to the root of the tree prefab and set its **Mode** to **Remove Object**. That setting applies to every instance of that tree prototype, in every terrain, for the agent types listed in the modifier's **Affected Agents**. To keep the trees of every terrain out of the NavMesh across a whole project, add `AI_NAVIGATION_IGNORE_TERRAIN_TREES` to the **Scripting Define Symbols** in **Project Settings** &gt; **Player**. This removes the collection of terrain trees from the package altogether, so it adds nothing to the bake, whereas a **NavMesh Modifier** still inspects each tree prototype and visits each tree instance before discarding it.
* When a tree prototype has no geometry and no modifier volume that the bake can use, a warning in the Console now names that prefab. For example, this happens when the LOD selected by the prototype's **NavMesh LOD** contains only a billboard renderer, which has no mesh.

### Fixed
* `NavMeshSurface` now bakes the trees painted on a terrain into the NavMesh, taking either the render meshes or the colliders of each tree prefab according to its **Use Geometry** setting. It collects a terrain's trees only when that terrain's layer is in its **Include Layers** mask, then filters each tree instance by its `CollectObjects` mode, and applies any `NavMeshModifier` component found on the tree prefab, including `ignoreFromBuild`, area overrides and agent-type filtering. ([UUM-133541](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-133541))
* A `NavMeshModifierVolume` component on a tree prefab now applies when that tree is painted onto a terrain. A tree prototype that contains only modifier volumes and no geometry acts as a brush that assigns area types across a terrain, without adding any tree-shaped geometry to the NavMesh.

## [2.0.15] - 2026-09-24
### Fixed
* Fixed the **NavMeshSurface** entry of the **Gizmos** menu changing the appearance of the NavMesh visualization. It now only controls the display of the bounding box of the surface. ([UUM-133537](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-133537))
* Fixed a focused input field from the **Agents** tab of the **Navigation** window being drawn in an unrelated row of the **Areas** tab after switching tabs. (UUM-149872)
* Fixed the bounds computed by a **NavMesh Surface** stretching all the way to the position of its GameObject when all the collected objects were located away from it. This made the NavMesh bake slower and displayed misleading bounds in the Scene view. ([UUM-133538](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-133538))

## [2.0.14] - 2026-06-04
### Changed
* The samples now use the Input System package (`com.unity.inputsystem`) for player input instead of the legacy Input Manager.

### Fixed
* The **AI Navigation** preferences were not searchable from the Preferences window search field.
* Errors from NavigationOverlay logged to the console when the NavMeshAgent was selected at the start of playmode.
* Fixed the options in the **AI Navigation** overlay overlapping each other when the overlay was squished. The options panel is now wrapped in a scroll view. ([UUM-133539](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-133539))

## [2.0.13] - 2026-06-01
### Fixed
* Fixed static data not being cleared correctly when using Fast Enter Playmode.

## [2.0.12] - 2026-03-18
### Fixed
* Fixed exception being thrown on Linux when opening the settings windows.

## [2.0.11] - 2026-02-20
### Fixed
* Small correction in the UI definition of the Navigation Updater window.

## [2.0.10] - 2026-01-27
### Fixed
* Warning _Object.GetInstanceID()' is obsolete: 'GetInstanceID is deprecated_ was logged to the console in Unity 6.2 and newer.

### Changed
* The unit test scripts are no longer delivered with the package.

## [2.0.9] - 2025-08-28
### Added
* New sample scene **9_agent_cornering_control** to demonstrate controlling an agent's velocity in order to better navigate tight corners. ([UUM-59747](https://issuetracker.unity3d.com/product/unity/issues/guid/UUM-59747))

### Fixed
* Fixed samples not correctly configuring navigation agent types when imported into a project.
* Foldouts in **AI Navigation** overlay collapse when toggling settings. ([NAVB-144](https://issuetracker.unity3d.com/product/unity/issues/guid/NAVB-144))
* Fixed poor performance when enabling/disabling increasing numbers of NavMeshModifiers. ([NAVB-96](https://issuetracker.unity3d.com/product/unity/issues/guid/NAVB-96))
* A small white square was displayed in the scene on top of the gizmo icons for NavMesh Link, NavMesh Modifier Volume and NavMesh Surface. ([NAVB-154](https://issuetracker.unity3d.com/product/unity/issues/guid/NAVB-154))
* **Navigation Updater** no longer attempts to process scenes and prefabs from the read-only **Packages** folder. ([NAVB-146](https://issuetracker.unity3d.com/product/unity/issues/guid/NAVB-146))

## [2.0.8] - 2025-05-29
### Fixed
* Samples will now use appropriate material colors in projects using HDRP or URP. Install the **com.unity.shadergraph** package to show the materials correctly for built-in render pipeline projects.

## [2.0.7] - 2025-04-09
### Changed
* The minimum supported editor version is Unity 6 LTS. Compatibility with Unity 2023.2 is no longer guaranteed going forward.

### Fixed
* Baking NavMeshSurface no longer fails when the game object name has invalid file name characters.

## [2.0.6] - 2025-02-04
### Added
* New **OffMesh Link Converter** tool in the **Window** > **AI** > **Navigation Updater** window to help you automatically replace **OffMesh Links** with **NavMesh Links** in the scenes and prefabs of your project.

### Fixed
* Fixed a regression that caused controls in the navigation scene view overlay popup to display on top of one another when foldouts were open. (Requires Unity 6000.0.22f1 or newer)
* The AI Navigation overlay was rarely needed upon the initial installation of the package. Now it is hidden by default and you can enable it through the [Overlay Menu](https://docs.unity3d.com/Manual/display-and-hide-overlay.html).
* Fixed a regression that caused the Editor to allocate unnecessary memory on some platforms, when the project contained package test files.

## [2.0.5] - 2024-11-18
### Fixed
* NavMesh Link would not update when switching from the **Not Walkable** area type to any other area type in the inspector. (NAVB-87)
* A few documentation paragraphs and links were not accurate.

## [2.0.4] - 2024-08-30
### Fixed
* NavMesh Modifier was not overriding the area type in a NavMesh built from within an `Awake()` method ([NAVB-39](https://issuetracker.unity3d.com/issues/building-navmesh-with-navmeshsurface-does-not-bake-areas-into-navmeshtriangulation-when-buildnavmesh-is-called-in-awake))

## [2.0.3] - 2024-07-16
### Changed
* The ends of the NavMesh Link are solely determined by the Transforms they reference. If a link's end doesn't reference a Transform, it is placed in the scene according to the local Point position set for it. This differs from version 2.0.0 where the Point was used together with, and relative to, the end's Transform, which always pointed to some GameObject. NavMesh Links saved using version 2.0.0 will now find their endpoints in different positions compared to where they would be in version 2.0.0. NavMesh Links saved with versions earlier than 2.0.0 remain unaffected and will continue to function with their existing data as they used to.
* NavMesh Links saved with version 2.0.0 upgrade automatically to the correct format. Any link endpoint that has previously been defined by a position relative to a GameObject will now reference a new GameObject created as a child of the original transform and moved to the same world position that the endpoint had before.
* To modify the cost of an individual NavMesh Link you can now select "Cost Override" in the Inspector and then input the new value. NavMesh Links that are saved with this version cannot be loaded correctly with earlier versions of the package.
* Improved the user manual pages that describe the NavMesh Link and the NavMesh Surface components.

### Fixed
* Fixed navigation objects created from the GameObject menu being created in the scene instead of a prefab hierarchy when in prefab isolation mode.
* Fixed creation of navigation objects from the GameObject menu resulting in more than one operation on the undo stack.
* In accordance with other workflows, creating navigation objects from the GameObject menu now places them directly at the parent's position, instead of at the center of the scene view, when a parent is selected.
* Fixed regression whereby changing NavMeshLink activated or cost modifier properties in the Inspector would not update the link while in play mode.
* Added missing tooltips and support for localization throughout Inspector UI.
* The Navigation window was sometimes issuing errors related to the .png file used as icon.
* Added a cleanup step for Navigation components static data, so that the components support entering play mode without any domain reload.
* Fixed warnings in the console when undoing creation of navigation objects from the GameObject menu.
* Swapping the start and end points of a NavMeshLink via the Inspector now supports undo and redo.
* Moving the GameObject via the Re-center operation in the NavMesh Link Inspector now supports undo and redo.
* The deprecated properties `autoUpdatePositions`, `biDirectional`, `costOverride` and the deprecated `UpdatePositions` method of NavMeshLink correctly map now one-to-one to the members `autoUpdate`, `bidirectional`, `costModifier` and `UpdateLink`. This change removes any values that were stored by a serialized object specifically for the deprecated properties.
* Updated the use of several methods that have been moved between classes as of 2023.3.
* Added missing documentation for method parameters in `NavMeshComponentsGUIUtility`.

## [2.0.2] - 2024-07-02
_Version not published._

## [2.0.1] - 2023-12-06
_Version not published._

## [2.0.0] - 2023-10-17
_NavMesh Link sets incorrect endpoint transforms and positions. Use version 2.0.3 instead._

### Fixed
* When the "Auto Update Position" option of NavMeshLink is enabled, the link now correctly updates the connection in the next frame after any of the link's ends change their world position.

## [2.0.0-pre.4] - 2023-09-28
### Fixed
* Long warning popping up when user starts playmode while editing a prefab that contains NavMesh components ([NAVB-47](https://issuetracker.unity3d.com/product/unity/issues/guid/NAVB-47))

## [2.0.0-pre.3] - 2023-05-31
### Added
* New `activated` property in NavMeshLink, useful to control whether agents are allowed to traverse the link
* New `occupied` property in NavMeshLink, useful to determine whether an agent is using the link
* New `startTransform`, `endTransform` properties in NavMeshLink, useful to define the ends of the link through Transform references as an alternative to points in 3D space
* New `autoUpdatePositions`, `biDirectional`, `costOverride` properties and the `UpdatePositions()` method, introduced as "deprecated" in order to facilitate the upgrade from OffMeshLinks

### Changed
* The `costModifier` property is now of type `float`, as expected by the Navigation system.

### Fixed
* Published the missing API reference documentation for the properties made available with 2022.2

### Removed
* The "Navigation (Obsolete)" window has been removed. This in turn removes the deprecated abilities to enable the "Navigation Static" flag on scene objects and to bake a single NavMesh embedded in the scene.

## [1.1.3] - 2023-04-13
### Changed
* Remove some unnecessary files from the package

## [1.1.2] - 2023-04-03
### Changed
* The _AI Navigation_ overlay in the scene view remembers which sections have been collapsed
* Updated a large part of the documentation to reflect the current functionality

## [1.1.1] - 2022-10-21
### Changed
* Clarified the information text displayed by the NavMesh Updater

## [1.1.0-pre.2] - 2022-08-09
### Changed
* The Dungeon scene included in the package samples now uses tile prefabs that contain a `NavMeshSurface` component instead of the `NavMeshPrefabInstance` script.
* The Drop Plank scene included in the package samples now has a `NavMeshSurface` component and the `NavMeshSurfaceUpdater` script on the geometry, as well as the `DynamicNavMeshObject` script on the Plank prefab for dynamically updating the `NavMesh` when new Planks are instantiated.
* The offset when instantiating Planks in the Drop Plank scene has been reduced.
* The Sliding Window Infinite and the Sliding Window Terrain scenes included in the package samples now use the `NavMeshSurfaceVolumeUpdater` script instead of the `LocalNavMeshBuilder` and `NavMeshSourceTag` scripts for dynamically updating the `NavMesh`.
* The Modify Mesh scene included in the package samples now uses a `NavMeshSurface` component on the Mesh Tool for dynamically updating the `NavMesh` instead of the `LocalNavMeshBuilder` and `NavMeshSourceTag` scripts. The `MeshTool` script now uses the `Update()` method of `NavMeshSurface` for updating the `NavMesh` whenever the mesh is modified.

### Fixed
* The Drop Plank scene included in the package samples now destroys instantiated Planks that have fallen off the edge.
* Missing agent type references in the samples.

### Removed
* The `NavMeshPrefabInstance` and `NavMeshPrefabInstanceEditor` scripts from the package samples were removed.
* The prefab editing scene `7b_dungeon_tile_prefabs` from the package samples was removed. The tiles can now be edited directly as prefabs.
* The `LocalNavMeshBuilder` and `NavMeshSourceTag` scripts from the package samples were removed.

## [1.1.0-pre.1] - 2022-04-27
### Added
* NavMeshSurface supports links generation.
* NavMeshSurface supports HeightMesh baking.
* New package Navigation window adapting the obsolete Unity Navigation window functionalities to the package workflow.

### Changed
* NavMeshSurface is using the _Background Tasks_ window to report the baking progress
* Minimum supported version is increased to Unity 2022.2

## [1.0.0-exp.4] - 2021-07-19
### Changed
* Documentation updated with changes from Unity manual
* Test scripts moved into namespaces Unity.AI.Navigation.Tests and Unity.AI.Navigation.Editor.Tests

## [1.0.0-exp.3] - 2021-06-16
### Fixed
* An assembly definition in the package sample was referencing an invalid AsmDef

## [1.0.0-exp.2] - 2021-05-19
### Fixed
* Baking a NavMeshSurface with a bounding volume was not detecting the geometry nearby the bounds (1027006)

### Changed
* New note in the documentation about the bounding volume of a NavMeshSurface

## [1.0.0-exp.1] - 2021-04-06

This is the first release of the *AI Navigation* package. It contains the scripts that were previously known as *NavMeshComponents* and it adds a few improvements.

### Fixed
* Disabling a NavMeshLink component in the Editor does not remove the link

### Added
* New `minRegionArea` property in `NavMeshSurface` that prevents small isolated patches from being built in the NavMesh
* Documentation for the new `minRegionArea` property

### Changed
* Documentation updated
* Script namespaces changed to Unity.AI.Navigation.*
* The [license](LICENSE.md) has changed.
* The folder structure has changed in accordance to the requirements of the Unity standards for packages.
